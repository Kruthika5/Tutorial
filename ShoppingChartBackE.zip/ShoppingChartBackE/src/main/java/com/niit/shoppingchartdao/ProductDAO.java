package com.niit.shoppingchartdao;

import java.util.List;

import com.niit.shoppingchartmodel.Product;



public interface ProductDAO {
	public List<Product> list();
	public Product get(String id);
	public void saveOrUpdate(Product product);
	public void delete(String id);
	public Product getByName(String name);


}
