package com.niit.shoppingchartmodel;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="User")
@Component
public class User {
	private String u_id;
	private String u_name;
	private String u_password;
	private String u_mobileno;
	private String u_mailadd;
	private String u_resadd;
	
	@Id
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_password() {
		return u_password;
	}
	public void setU_password(String u_password) {
		this.u_password = u_password;
	}
	public String getU_mobileno() {
		return u_mobileno;
	}
	public void setU_mobileno(String u_mobileno) {
		this.u_mobileno = u_mobileno;
	}
	public String getU_mailadd() {
		return u_mailadd;
	}
	public void setU_mailadd(String u_mailadd) {
		this.u_mailadd = u_mailadd;
	}
	public String getU_resadd() {
		return u_resadd;
	}
	public void setU_resadd(String u_resadd) {
		this.u_resadd = u_resadd;
	}
	

	
	
	
}
