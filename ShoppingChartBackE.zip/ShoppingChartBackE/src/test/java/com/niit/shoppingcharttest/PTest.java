package com.niit.shoppingcharttest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingchartdao.CategoryDAO;
import com.niit.shoppingchartdao.ProductDAO;
import com.niit.shoppingchartmodel.Category;
import com.niit.shoppingchartmodel.Product;

public class PTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		ProductDAO productDAO =(ProductDAO) context.getBean("productDAO");
		
		Product product= (Product) context.getBean("product");
		
		
		
		product.setId("id");
		product.setName("abcd");
		product.setPrice("p_price");
		product.setDescription("p_de");
		
		
		
		//productDAO.delete("id");
		
	
	productDAO.saveOrUpdate(product);
		
		/*if(   categoryDAO.getCategory("id") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  }*/
			
				}

}
