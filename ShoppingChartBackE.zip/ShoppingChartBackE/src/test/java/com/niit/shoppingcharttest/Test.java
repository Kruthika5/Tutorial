package com.niit.shoppingcharttest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingchartdao.CategoryDAO;
import com.niit.shoppingchartmodel.Category;

public class Test {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		
		Category category=(Category) context.getBean("category");
		
		
		
		category.setId("456");
		category.setName("def");
		category.setDescription("akaka567");
		
		
		
		//categoryDAO.delete("id");
		
		
		//categoryDAO.saveOrUpdate(category);
		
		if(   categoryDAO.get("id") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  
			
				}

	}
}

