/*package com.niit.shoppingcharttest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingchartdao.UserDAO;
import com.niit.shoppingchartmodel.UserDetails;

public class TestUserDAO {

  @Autowired
	static UserDAO userDAO;

	@Autowired
	static UserDetails userDetails;

	static AnnotationConfigApplicationContext context;

	@BeforeClass
	public static void init() {
		System.out.println("init method");
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();

		userDAO = (UserDAO) context.getBean("userDAO");
		userDetails = (UserDetails) context.getBean("userDetails");

	}

	@Test
	public void UsersTestCase() {
		int size = userDAO.list().size();

		assertEquals("User list test case", 0, size);

	}

	
	 @AfterClass
	 public static void close() { 
		 context.close(); 
		 userDAO=null;
	     userDAO=null;
	  
	  }
	  
	 @Test 
	 public void UserNameTestCase() { 
		  userDetails=userDAO.get("niit");
		  String name=userDetails.getName();
		  assertEquals("Name test case","niit", name);
	  
	  }
	

}*/