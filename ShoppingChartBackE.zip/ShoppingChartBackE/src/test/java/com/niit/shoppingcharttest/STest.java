package com.niit.shoppingcharttest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shoppingchartdao.SupplierDAO;
import com.niit.shoppingchartmodel.Supplier;

public class STest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		SupplierDAO supplierDAO =(SupplierDAO) context.getBean("supplierDAO");
		
		Supplier supplier=(Supplier) context.getBean("supplier");
		
		
		
		
		supplier.setId("s_id");
		supplier.setName("abc");
		supplier.setAdd("asdfg");
		
		
		//supplierDAO.delete("123");
		
		
		supplierDAO.saveOrUpdate(supplier);
		
		/*if(   categoryDAO.getCategory("id") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  }*/
			
				}

}
