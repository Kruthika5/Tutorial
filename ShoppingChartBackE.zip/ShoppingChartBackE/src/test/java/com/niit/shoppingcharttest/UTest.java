package com.niit.shoppingcharttest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.shoppingchartdao.UserDAO;
import com.niit.shoppingchartmodel.UserDetails;

public class UTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
	    UserDAO userDAO= (UserDAO) context.getBean("userDAO");
		
	    UserDetails userDetails=(UserDetails) context.getBean("userDetails");
		
		
		
		
		userDetails.setId("5");
		userDetails.setName("abc");
		userDetails.setAddress("asdf");
		userDetails.setEmail("yamail");
		userDetails.setMobile("789");
		userDetails.setPassword("sanju");
		userDetails.setAdmin(0);;
		
		//userDAO.delete("3");
		
		
		userDAO.saveOrUpdate(userDetails);
		
		/*if(   categoryDAO.getCategory("id") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  }*/
			
				}

}
