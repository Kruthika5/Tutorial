package com.niit.shoppingcart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingchartdao.CategoryDAO;
import com.niit.shoppingchartmodel.Category;
import com.niit.shoppingchartutil.util;


@Controller
public class CategoryController {
	Logger log = LoggerFactory.getLogger(CategoryController.class);

	@Autowired
    CategoryDAO categoryDAO;

	@Autowired
	 Category category;

	
	
	@RequestMapping(value = "/category", method = RequestMethod.GET)
	public String listCategory(Model model) {
		model.addAttribute("category",category);
		model.addAttribute("categoryList",this.categoryDAO.list());
		return "category";
	}

	// For add and update category both
	@RequestMapping(value = "/category/add", method = RequestMethod.POST)
	public String addCategory(@ModelAttribute("category") Category category) {

		util util = new util();
		String id=  util.replace(category.getId(), ",", "");
		category.setId(id);

		categoryDAO.saveOrUpdate(category);

		return "redirect:/category";
		//return "category";

	}

	@RequestMapping("category/remove/{id}")
	public String deleteCategory(@PathVariable("id") String id, ModelMap model) throws Exception {
		categoryDAO.delete(id);
        return "redirect:/category";
	}
		
		/*try {
			categoryDAO.delete(id);
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		// redirectAttrs.addFlashAttribute(arg0, arg1)
		return "/category";
	}*/

	@RequestMapping("category/edit/{id}")
	public String editCategory(@PathVariable("id") String id, Model model) {
		System.out.println("editCategory");
		model.addAttribute("category",this.categoryDAO.get(id));
		model.addAttribute("listCategory",this.categoryDAO.list());
		return "category";
	}
	

}
