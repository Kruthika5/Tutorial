package com.niit.shoppingcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingchartdao.CategoryDAO;
import com.niit.shoppingchartdao.UserDAO;
import com.niit.shoppingchartmodel.Category;
import com.niit.shoppingchartmodel.UserDetails;



@Controller
public class UserController {
	@Autowired
	UserDAO userDAO;
	@Autowired
	UserDetails userDetails;
	@Autowired
	Category category;
	@Autowired
	CategoryDAO categoryDAO;
	
	@RequestMapping("/")
	   public String getLanding()
	   {
	   return"index";
	   
	   }
	
	/*@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value = "name") String userID,
			@RequestParam(value = "password") String password, HttpSession session) {
		
	
		ModelAndView mv = new ModelAndView("home");
		boolean isValidUser = userDAO.isValidUser(userID, password);

		if (isValidUser == true) {
			userDetails = userDAO.get(userID);
			session.setAttribute("loggedInUser", userDetails.getName());
			if (userDetails.getAdmin() == 1) {
				mv.addObject("isAdmin", "true");

			} else {
				
				   mv.addObject("message","welcome"+userDetails.getName());			   
				   
				   

			}

		} else {

			mv.addObject("invalidCredentials", "true");
			mv.addObject("errorMessage", "Invalid Credentials");
			

		}
		
		return mv;
	}*/

	 
	@RequestMapping("/login")
	   public String getlogin()
	   {
	   return"login";
	   
	   }
	
	@RequestMapping("/check")
	   public ModelAndView login(@RequestParam(name="name")String name,@RequestParam(name="password")String password)
{
	   ModelAndView mv;	   
	   boolean isValidUser=userDAO.isValidUser(name,password);
	   if(isValidUser){
		   mv =new ModelAndView("/adminhome");
		   userDetails=userDAO.get(name);
		   if(userDetails.getAdmin()==1)
		   {
			   mv.addObject("message","welcome admin"+userDetails.getName());
			   
		   }
		   else
		   {
		   mv.addObject("message","welcome"+userDetails.getName());			   
		   }
		   
}
else{
		   mv=new ModelAndView("/Fail");
		   mv.addObject("message","Invalid user");
		  
	   }	
	   
	   return mv;
}

	
@RequestMapping("/contact")
public String getcontact()
{
	return"contact";
}

@RequestMapping("/about")
public String getabout()
{
	return"about";
}
	   
}


