package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.niit.shoppingcart.util.FileUtil;
import com.niit.shoppingchartdao.CategoryDAO;
import com.niit.shoppingchartdao.ProductDAO;
import com.niit.shoppingchartdao.SupplierDAO;
import com.niit.shoppingchartmodel.Category;
import com.niit.shoppingchartmodel.Product;
import com.niit.shoppingchartmodel.Supplier;
import com.niit.shoppingchartutil.util;

@Controller
public class ProductController {
	
	@Autowired
	ProductDAO productDAO;
	@Autowired
	CategoryDAO categoryDAO;
	@Autowired
	SupplierDAO supplierDAO;
	@Autowired
	Product product;
	
	private String path="D://kruthika//images";
	
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String listProduct(Model model) {
		model.addAttribute("product", new Product());
		model.addAttribute("category", new Category());
		model.addAttribute("supplier",new Supplier());
		model.addAttribute("productList",this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
				return "product";
	}

	@RequestMapping(value = "/product/add", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product) {

		util util = new util();
		String id=  util.replace(product.getId(), ",", "");
		product.setId(id);
		Category category = categoryDAO.getByName(product.getCategory().getName());
		categoryDAO.saveOrUpdate(category); // why to save??

		Supplier supplier = supplierDAO.getByName(product.getSupplier().getName());
		supplierDAO.saveOrUpdate(supplier); // Why to save??
		

		product.setCategory(category);
		product.setSupplier(supplier);

		product.setC_id(category.getId());
		product.setS_id(supplier.getId());
		productDAO.saveOrUpdate(product);
		
	     MultipartFile file =product.getImage();
		 
		FileUtil.upload(path, file,product.getId()+".jpg");
	

		return "redirect:/product";
		//return "product";

	}

	@RequestMapping("product/remove/{id}")
	public String deleteProduct(@PathVariable("id") String id, ModelMap model) throws Exception {
		productDAO.delete(id);
        return "redirect:/product";
	}
		
		/*try {
			categoryDAO.delete(id);
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		// redirectAttrs.addFlashAttribute(arg0, arg1)
		return "/category";
	}*/

	@RequestMapping("product/edit/{id}")
	public String editCategory(@PathVariable("id") String id, Model model) {
		System.out.println("edit product");
		model.addAttribute("product",this.productDAO.get(id));
		model.addAttribute("listProduct",this.productDAO.list());
		return "product";
	}
	
	
	
	
	

}
