package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingchartdao.SupplierDAO;
import com.niit.shoppingchartmodel.Supplier;
import com.niit.shoppingchartutil.util;

@Controller
public class SupplierController {
	
	@Autowired
	SupplierDAO supplierDAO;
	
	@Autowired
	Supplier supplier;
	
	@RequestMapping(value = "/supplier", method = RequestMethod.GET)
	public String listSupplier(Model model) {
		model.addAttribute("supplier", supplier);
		model.addAttribute("supplierList",this.supplierDAO.list());
		return "supplier";
	}

	// For add and update category both
	@RequestMapping(value = "/supplier/add", method = RequestMethod.POST)
	public String addSupplier(@ModelAttribute("supplier") Supplier supplier) {

		util util = new util();
		String id=  util.replace(supplier.getId(), ",", "");
		supplier.setId(id);
		
		supplierDAO.saveOrUpdate(supplier);

		return "redirect:/supplier";
		//return "supplier";

	}

	@RequestMapping("supplier/remove/{id}")
	public String deletesupplier(@PathVariable("id") String id, ModelMap model) throws Exception {
		supplierDAO.delete(id);
        return "redirect:/supplier";
	}
		
		/*try {
			categoryDAO.delete(id);
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		// redirectAttrs.addFlashAttribute(arg0, arg1)
		return "/category";
	}*/

	@RequestMapping("supplier/edit/{id}")
	public String editSupplier(@PathVariable("id") String id, Model model) {
		System.out.println("edit Supplier");
		model.addAttribute("supplier",this.supplierDAO.get(id));
		model.addAttribute("listSupplier",this.supplierDAO.list());
		return "/supplier";
	}

}
